const faker = require('faker');
const axios = require('axios');

console.log(faker.name.findName())
console.log(faker.name.findName())
console.log(faker.name.findName())
console.log(faker.name.findName())
console.log(faker.name.findName())
// console.log(axios)