// const helpers = require('./helpers')
const { add, subtract, color } = require('./helpers')

console.log(color)
console.log(subtract(5, 2))
console.log(add(22, 45))

