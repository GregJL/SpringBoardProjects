const { add, User } = require('./usefulStuff');

const results = add(2, 3);

console.log(results);
