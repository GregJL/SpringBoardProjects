const usefulStuff = require("./usefulStuff");

const results = usefulStuff.add(2, 3);

console.log(results);