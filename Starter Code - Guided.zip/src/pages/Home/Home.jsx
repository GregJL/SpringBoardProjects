import styles from "./Home.module.css";

function Home ()
{
	return (
		{
			// todo
		}
	);
}

export default Home;
