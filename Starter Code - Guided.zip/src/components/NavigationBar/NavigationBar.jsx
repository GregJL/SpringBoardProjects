import {NavLink} from "react-router-dom";

import styles from "./NavigationBar.module.css";

function NavigationBar ()
{
	return (
		{
			// todo
		}
	);
}

export default NavigationBar;
