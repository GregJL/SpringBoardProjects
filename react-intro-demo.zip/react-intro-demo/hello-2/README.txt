Hello-2
=======

An improved "Hello World" that demonstrates using properties.

So we can re-use the `Hello` component, we split the JS into
a file that just contains the hello component, `hello.js`, and
one that renders our demo of it, `index.js`.