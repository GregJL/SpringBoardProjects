function Hello() {
  return <p>Hi Rithm!</p>
}

ReactDOM.render(<Hello/>,
  document.getElementById("root"));
