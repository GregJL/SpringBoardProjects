const RandomNum = () => {
  const rand = Math.floor(Math.random() * 10) + 1;
  return <h3>{rand}</h3>
}

