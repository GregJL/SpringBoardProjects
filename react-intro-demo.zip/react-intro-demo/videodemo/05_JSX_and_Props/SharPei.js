const SharPei = () => (
  <img src="https://i.pinimg.com/originals/60/16/ea/6016eaad1a6779310b73cdd002cc974e.jpg" />
)
