const App = () => (
  <div>
    <h2>Dogs!</h2>
    <Shiba />
    <SharPei />
    <Shiba />
  </div>
)



ReactDOM.render(<App />, document.getElementById("root"))
