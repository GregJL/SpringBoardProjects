import React from "react";
import "./App.css";
import EightBall from "./EightBall";

/** Show magic eight ball. */

function App() {
  return (
    <div className="App">
      <EightBall />
    </div>
  );
}

export default App;
