import React from "react";
import "./App.css";
import BoxesContainer from "./BoxesContainer";

function App() {
  return (
    <div className="App">
      <BoxesContainer />
    </div>
  );
}

export default App;
