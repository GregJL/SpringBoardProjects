import React from "react";
import SimpleCounter from "./SimpleCounter";

function App() {
  return (
    <div>
      <h1>Simple Counter</h1>
      <SimpleCounter />
    </div>
  );
}

export default App;
