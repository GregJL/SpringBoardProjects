import React from "react";
import NumberList from "./NumberList";

function App() {
  return (
    <div className="App">
      <h2>Number list:</h2>
      <NumberList />
    </div>
  );
}

export default App;
