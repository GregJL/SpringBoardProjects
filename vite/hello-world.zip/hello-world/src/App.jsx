import "./App.css";

function App ()
{
	return (
		<>
			Hello, World!
		</>
	);
}

export default App;
