/** get a random integer between 0 and max. */
function getRandom(max) {
  return Math.floor(Math.random() * max);
}

export { getRandom };