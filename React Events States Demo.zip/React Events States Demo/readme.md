Reference and starter code for React State exercises

Please do note, Colt videos are using CRA (Create React App) which is as of
2024 not being maintained anymore.

Starter and reference code uses Vite to package, setup and run React

Make sure you use our Vite reference videos and ensure that your Node

version is at least 18.0.0

1. CD into the appropriate folder.
2. "npm install" or "yarn install" (use your favorite package manager)
3. "npm run dev" or "yarn dev"
4. Follow along with the videos :)
