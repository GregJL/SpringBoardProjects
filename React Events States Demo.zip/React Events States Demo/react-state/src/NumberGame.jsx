import React, { useState } from "react";
import "./NumberGame.css";

/*
Follow along for <Number Game State> video as well
ass <Building on Number Game> video
*/

const NumberGame = (props) => {
  return (
    <div>

    </div>
  );
};

export default NumberGame;