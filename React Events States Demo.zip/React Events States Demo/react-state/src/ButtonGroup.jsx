import React from "react";

const ButtonGroup = () => {
  const printColor = () => {
    // code here //
  };

  return (
    <div>
      <button onClick={printColor}>RED</button>
      <button onClick={printColor}>YELLOW</button>
      <button onClick={printColor}>GREEN</button>
    </div>
  )
};

export default ButtonGroup;