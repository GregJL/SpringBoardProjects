import React from "react";

const Clicker = () => {
  return (
    <button>CLICK ME</button>
  );
};

export default Clicker;