import React from "react";

/*
Folllow along for the <useState> intro video
*/

const Counter = () => {
  return (
    <>
      <h1>Count is 0</h1>
      <button>Add</button>
    </>
  );
};

export default Counter;