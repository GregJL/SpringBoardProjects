import React from "react";
import ButtonGroup from "./ButtonGroup";
import Clicker from "./Clicker";
import Counter from "./Counter";
import NumberGame from "./NumberGame";


/*
Attention: 
This is the starter code for 38.5 Events and State videos 

Follow along with Colt through the Events and State exercises
*/

function App() {

  return (
    <div className="app">
      <Clicker />
    </div>
  );
}

export default App;
