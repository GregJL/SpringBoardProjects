import styles from "./App.module.css";

function App ()
{
  return (
    <>
      <h1>Space Travel</h1>
    </>
  );
}

export default App;
